import React, { createContext, useState, useContext } from "react";
import { parse } from "uuid";
export const GameContext = createContext({});
export function GameContextProvider({ children }) {
  const [gameState, setGameState] = useState([]);
  const [roomCode, setRoomCode] = useState([]);
  const [playerName, setPlayerName] = useState([]);
  const [controllerKey, setControllerKey] = useState("");
  const [fullLog, setFullLog] = useState([]);
  const [websocket, setWS] = useState(null);
  const [inRoom, setInRoom] = useState(false);
  function checkInRoom() {
    return checkInRoom;
  }

  async function establishWebSocketConnection() {
    const wsURL = `ws://localhost:8080/?join=${roomCode}&name=${playerName}`
    console.log(wsURL)
    let ws = new WebSocket(wsURL);
    ws.onerror = ws.onmessage = ws.onopen = ws.onclose = null;
    ws.onerror = (e) => {
      //showSystemMessage(`WebSocket error.`);
    };
    ws.onopen = function () {
      //showSystemMessage('WebSocket connection established');
      setInRoom(true);
    };
    ws.onclose = function () {
      //showSystemMessage('WebSocket connection closed');
      closeConnection();
    };
    ws.onmessage = ((event) => {
      console.log(`messaged`)
      const obj = JSON.parse(event.data);
      handleIncomingMessage(obj);
    });
    setWS(ws);
  };

  function closeConnection() {
    setInRoom(false);
  }

  function handleIncomingMessage({ type, sender, status, data }) {

    let parsedData;
    if (data) {
      parsedData = JSON.parse(data)
      console.log(parsedData);
    }

    if (type === 'FULL_LOG' || type === 'LOG') {
      //all chat and log messages are sent in a bundle and the client can filter accordingly
      if (!parsedData) {
        console.warn(`No data present in the chat log!`)
        return;
      }
      setFullLog(parsedData);
      return;
    }
    if (type === 'update_log') {
      //fullyUpdateChat(obj);
      return;
    }
    if (type === 'room_stats') {
      //TODO format show room info to the player
      //clearSystemMessages();
      //showSystemMessage(obj.message);
    }
    if (type === 'connect_confirm' && parsedData.controllerKey === controllerKey) {
      //showSystemMessage(obj.message)
      return;
    }
    if (type === 'server') {
      //showSystemMessage(`${obj.result}: ${obj.message}.${obj.status}`);
    }
  }

  function sendLog(text) {
    const message = {
      type: "LOG",
      text: text,
      sender: playerName,
    }

    websocket.send(JSON.stringify(message));
  }
  function sendChat(text) {
    const message = {
      type: "CHAT",
      text: text,
      sender: playerName,
    }

    websocket.send(JSON.stringify(message));

    console.log(message);
  }

  return (
    <GameContext.Provider
      value={{
        gameState: gameState,
        setGameState,
        roomCode: roomCode,
        setRoomCode,
        playerName,
        setPlayerName,
        establishWebSocketConnection,
        fullLog,
        sendChat,
        sendLog,
        closeConnection,
        inRoom: inRoom,
      }}
    >
      {children}
    </GameContext.Provider>
  );
}
export const useGameContext = () => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error(
      "useGameContext must be used within a GameContextProvider"
    );
  }
  return context;
};