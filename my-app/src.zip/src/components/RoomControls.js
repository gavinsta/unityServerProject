import JoinRoom from "./JoinRoom";
import { GameContext, useGameContext } from "../contexts/GameContext";
export function RoomControls() {
  const { inRoom, roomCode, setRoomCode, playerName, setPlayerName, closeConnection } = useGameContext();

  return (
    <div
      style={{ height: 30 }}>
      <InputText
        value={playerName}
        setValue={setPlayerName}
        isActive={!inRoom}
        label="NAME"
      />
      <InputText
        value={roomCode}
        setValue={setRoomCode}
        isActive={!inRoom}
        label="CODE"
      />
      {!inRoom ? <JoinRoom />
        : <button
          onClick={closeConnection}
        >
          Leave Room
        </button>}

    </div>
  );

};

export function InputText({ isActive = true, label, value, setValue }) {
  return (
    <input
      placeholder={label}
      type="text"
      value={value}
      onChange={e => {
        if (isActive) setValue(e.target.value.toUpperCase())
      }} />
  )
}