import { useStyleContext } from "../contexts/StyleContext";
import { LogDisplay } from "./LogDisplay";
export function PageContent() {
  const { pageType } = useStyleContext();
  return (
    <>
      {pageType === 'Controls' ? <p> Your selection: {pageType} </p>
        :
        <LogDisplay />}
    </>
  )
}